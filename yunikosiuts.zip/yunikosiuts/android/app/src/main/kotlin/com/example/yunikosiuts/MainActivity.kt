package com.example.yunikosiuts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
